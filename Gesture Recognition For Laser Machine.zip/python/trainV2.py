
import torch
from tqdm import tqdm
from torch.utils.data import DataLoader
from torchvision.transforms import transforms

from Dataset.ActionDatasetV3 import ActionDatasetV3
from Model.Mobile3DV2 import Mobile3DV2
from torch.nn import DataParallel
import pandas as pd
import os
import matplotlib.pyplot as plt

USE_CUDA = torch.cuda.is_available() # GPU를 사용가능하면 True, 아니라면 False를 리턴
device = torch.device("cuda" if USE_CUDA else "cpu") # GPU 사용 가능하면 사용하고 아니면 CPU 사용
print("다음 기기로 학습합니다:", device)


# configuration
imageHeight = 480
imageWidth = 640
cropHeight = 400
cropWidth = 560
resizeWidth = 320
resizeHeight = 240

learningRate = 0.001
momentum=0.9
weight_decay=1e-3
dampening=0.9
epochs = 500
classNum = 8
targetAcc = 0.999
batchSize = 116
frameNumber = 16
base_folder= "/home/saqib/Projects/action_recognition/action_recognition_git/actionclassification/trained"
# Create unique run folder
run_id = 1
while os.path.exists(os.path.join(base_folder, f"run_{run_id}")):
    run_id += 1
run_folder = os.path.join(base_folder, f"run_{run_id}")
os.makedirs(run_folder)


preLoad = False



# configuration


transformCollection = []
transformCollection.append(transforms.Resize((imageHeight, imageWidth)))
transformCollection.append(transforms.CenterCrop((cropHeight, cropWidth)))
transformCollection.append(transforms.Resize((resizeHeight, resizeWidth)))
transformCollection.append(transforms.RandomAutocontrast(p=0.4))
transformCollection.append(transforms.ToTensor()) 
transProcess = transforms.Compose(transformCollection)



dataset = trainDataset = ActionDatasetV3(path="/home/saqib/Projects/action_recognition/DataFrames", 
                                         bgPath="/home/saqib/Projects/action_recognition/Bg_images",
                                         transform=transProcess, 
                                         frameNumber=frameNumber, 
                                         imageWidth=imageWidth, 
                                         imageHeight=imageHeight,
                                         resizeWidth=resizeWidth,
                                         resizeHeight=resizeHeight,
                                         minTh=(50,50,50), 
                                         maxTh=(100, 255, 255))
tarinLoader = DataLoader(dataset, batch_size=batchSize, shuffle=True, drop_last=True)



model = Mobile3DV2(num_classes=classNum, width_mult=0.5)


######################### Using Multiple GPUs ############################
if torch.cuda.device_count() > 1:
    print(f"Using {torch.cuda.device_count()} GPUs")
    model = DataParallel(model)

model = model.to(device)  
###########################################################################

if preLoad == True:
    state_dict = torch.load("/home/saqib/Projects/action_recognition/action_recognition_git/actionclassification/trained/run_8_W320_H240_D16/Epoch_7_Acc_0.6853_loss_0.8452_best.pt", map_location=device, weights_only=True)
    weights = model.state_dict()
    model.load_state_dict(state_dict)

crossEntropy = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.RAdam(params=model.parameters(), lr=learningRate)
#scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=5, threshold=1e-3)
totalBatches = len(tarinLoader)
print('total batch = ', totalBatches)

trainDataset.summary()

max_acc = 0
metrics=[]
for epoch in range(epochs):
    avg_loss = 0
    avg_acc = 0
    
    print(f"Epoch {epoch + 1}/{epochs}")
    
    for i, (inputs, labels) in enumerate(tqdm(tarinLoader, desc="Training")):
        gpu_inputs = inputs.to(device)
        gpu_labels = labels.to(device)

        optimizer.zero_grad()
        model.train()
        output = model(gpu_inputs)
        loss = crossEntropy(output, gpu_labels.long())
        loss.backward()

        optimizer.step()
        avg_loss += (loss.item() / totalBatches)

    for i, (inputs, labels) in enumerate(tqdm(tarinLoader, desc="Evaluation")):
        gpu_inputs = inputs.to(device)
        gpu_labels = labels.to(device)

        model.eval()
        output = model(gpu_inputs)

        _, predicted = torch.max(output.data, 1)
        correct = (predicted == gpu_labels.long().to(device)).sum()
        total = labels.size(0)
        avg_acc += ((correct / total).item() / totalBatches)
    #print('current learning rate=', scheduler.get_last_lr())
    # scheduler.step(avg_loss)



    savePath_last = os.path.join(run_folder, f"Last_E_{epoch}_Acc_{avg_acc:.4f}_loss_{avg_loss:.4f}_W{resizeWidth}_H{resizeHeight}_D{frameNumber}.pt")
    savePath_best = os.path.join(run_folder, f"Best_E_{epoch}_Acc_{avg_acc:.4f}_loss_{avg_loss:.4f}_W{resizeWidth}_H{resizeHeight}_D{frameNumber}.pt")

    if max_acc < avg_acc:
        max_acc = avg_acc
        model.eval()
        torch.save(model.state_dict(), savePath_best)


    print('epoch = ', epoch, ', acc=', avg_acc, ', loss=', avg_loss)




    # Log metrics
    metrics.append({
        'Epoch': epoch + 1,
        'Train Loss': avg_loss,
        'Train Accuracy': avg_acc,
    })
    

    # Save metrics and plots every epoch
    metrics_df = pd.DataFrame(metrics)
    metrics_df.to_csv(os.path.join(run_folder, "metrics.csv"), index=False)

    plt.figure()
    plt.plot(metrics_df['Epoch'], metrics_df['Train Accuracy'], label='Train Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.savefig(os.path.join(run_folder, f"accuracy.png"))
    plt.close()

    plt.figure()
    plt.plot(metrics_df['Epoch'], metrics_df['Train Loss'], label='Train Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.savefig(os.path.join(run_folder, f"loss.png"))
    plt.close()

    if targetAcc <= avg_acc:
        print('training complete')
        break

model.eval()
torch.save(model.state_dict(), savePath_last)
